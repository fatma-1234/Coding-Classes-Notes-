const quesJSON = [
    {
        correctAnswer: 'Three',
        options: ['One', 'Two', 'Three', 'Four'],
        question: "How many pieces of bun are in a macdonald's Big Mac?",
    },
    {
        correctAnswer: 'L. Frank Baum',
        options: [
            'Suzzane Collins',
            'james Fenimore Cooper',
            'L. Frank Baum',
            'Danna Leon',
        ],
        question: "Which Author wrote ' The Wonderful Wizard of 0z'?",
    },
    {
        correctAnswer: 'Atlanta united',
        options: [
            'Atlanta united',
            'Atlanta impact',
            'Atlanta Bulls',
            'Atlanta stars',
        ],
        question: 'Which of these is a soccerr team based in Atlanta ?',
    },
    {
        correctAnswer: 'A Nanny',
        options: [
            'A Sow',
            'A Lioness',
            'A hen',
            'A Nanny',
        ],
        question: 'A female goat is known as what ?',
    },
    {
        correctAnswer: 'P. L. Travers',
        options: [
            'J R R Tolkein',
            'P. L. Travers',
            'Lewis Carroll',
            'Enid Blyton',
        ],
        question: "which author wrote 'marry Poppins'?",
    },
];

let score = 0;
let currentQuestion = 0;
const totalScore = quesJSON.length;

const questionEL = document.getElementById('question');
const scoreEL = document.getElementById('Score');
const optionsEL = document.getElementById('options');
const nextEL = document.getElementById('next');

showQuestion();
nextEL.addEventListener("click", nextQuestion);

function showQuestion() {
    const { correctAnswer, options, question } = quesJSON[currentQuestion];

    questionEL.textContent = question;

    const shuffledOptions = shuffleOptions(options);
    optionsEL.innerHTML = '';

    shuffledOptions.forEach((opt) => {
        const btn = document.createElement('button');
        btn.textContent = opt;
        optionsEL.appendChild(btn);

        btn.addEventListener("click", () => {
            if (opt === correctAnswer) {
                score++;
            } else {
                score -= 0.25;
            }
            scoreEL.textContent = `Score: ${score} / ${totalScore}`;
            nextEL.style.display = 'block';
        });
    });
}

function nextQuestion() {
    currentQuestion++;
    if (currentQuestion >= quesJSON.length) {
        questionEL.textContent = 'Quiz Completed!!';
        optionsEL.innerHTML = '';
        nextEL.remove();
    } else {
        showQuestion();
        nextEL.style.display = 'none';
    }
}

function shuffleOptions(options) {
    const shuffled = options.slice();
    for (let i = shuffled.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
}
