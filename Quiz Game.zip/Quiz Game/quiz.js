const quesJSON = [
    {
        correctAnswer:'Three',
        options:['One', 'Two', 'Three', 'Four' ],
        question:"How many pieces of bun are in a macdonald's Big Mac?",

},
{
    correctAnswer:'L. Frank Baum',
    options: [
        'Suzzane Collins',
        'james Fenimore Cooper',
        'L. Frank Baum',
        'Danna Leon',
    ],
    question:"Which Author wrote ' The Wonderful Wizard of 0z'?",
},
{
    correctAnswer:'Atlanta united',
    options:[
        'Atlanta united',
        'Atlanta impact',
        'Atlanta Bulls',
        'Atlanta stars',
    ],
    question:
    'Which of these is a soccerr team based in Atlanta ?',
},
{
    correctAnswer:'A Nanny',
    options:[
        'A Sow',
        'A Lioness',
        'A hen', 
        'A Nanny',
    ],
    question:
    'A female goat is known as what ?',

},
{
    correctAnswer:'P. L. Travers',
    options:[
        'J R R Tolkein',
        'P. L. Travers',
        'Lewis Carroll',
        'Enid Blyton',
    ], 
    question:
    "which author wrote 'marry Poppins'?",
    
},
];

// const questionObj = {
//     catogary: 'Food & Drink ',
//     id:'q1-1',
//     correctAnswer:'Three',
//     options: ['One', 'Two', 'Three', 'Four'],
//     question:"How many pieces of  bun are in a macdonald's Big Mac?",


// };

// const questionEL = document.getElementById("question");
// questionEL.textContent = questionObj.question;




let score = 0;
// to keep the count of the question lets create variable 
let currentQuestion = 0;
const totalScore = quesJSON.length;



// Accessing element 
const questionEL = document.getElementById('question');
// const correctAnswerEL = document.getElementById('correctAnswer');
const scoreEL = document.getElementById('Score');
const optionsEL = document.getElementById('options');
const nextEL = document.getElementById('next');


showQuestion();
nextEL.addEventListener("click", ()=>{
    scoreEL.textContent = `Score: ${score} / ${totalScore}`;
    nextQuestion()

});


   


function showQuestion(){
    // Destructuring the object 
const {
    correctAnswer,
    options,
    question,
    
} = quesJSON[currentQuestion];

// Setting quetion Text Content 
questionEL.textContent= question;

const shuffuledOptions = shuffleOptions(options);

shuffuledOptions= options.forEach((opt) => {
    // creating the button and and appending it to the options div 
    const btn = document.createElement('button');
    btn.textContent = opt;
    optionsEL.appendChild(btn);

    // Even handling on the button 
    btn.addEventListener("click", ()=>{

        if(opt === correctAnswer){
            score++;
            
        }else{
            score = score - 0.25;

        }
        // console.log(score);
        scoreEL.textContent = `Score: ${score} / ${totalScore}`;
        nextQuestion();

        // questionEL.textContent= 'Quiz completed !!';
        // optionsEL.textContent=' ';


         
    });
});


}

function nextQuestion(){
    currentQuestion++;
    optionsEL.textContent = '';  
    if(currentQuestion >= quesJSON.length){
        questionEL.textContent = 'Quiz Completed!!';
        nextEL.remove();
    }else{
        showQuestion();
    }
}


// Populating the options div with the buttons 
// Shuffling the options 
function shuffleOptions(options){
    for(let i = options.length-1; i>=0; i--){
        const j = Math.floor(Math.random() * i + 1);
        [options[i], options[j]] = [options[j], options[i]];

    }
    
    return options;
}


